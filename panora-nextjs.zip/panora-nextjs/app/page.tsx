'use client'
import dynamic from 'next/dynamic'
const PanoraApp = dynamic(() => import('../components/PanoraApp'), { ssr: false })

export default function Page() {
  return <PanoraApp />
}
