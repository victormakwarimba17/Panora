
# Panora — Next.js + TypeScript Starter (Tailwind)

This repo is a scaffolded Next.js + TypeScript project with Tailwind CSS and the Panora app component pre-installed.

## Quick start

1. Install dependencies
```bash
npm install
# or
yarn install
```

2. Run dev server
```bash
npm run dev
# open http://localhost:3000
```

3. Build for production
```bash
npm run build
npm run start
```

## Deploy to Vercel
1. Push this repo to GitHub.
2. Import project on Vercel — it will detect Next.js and build automatically.
3. Set `NODE_ENV` to `production` (optional).

---

Notes:
- This scaffold includes `lucide-react` and `framer-motion` as dependencies referenced by the Panora UI.
- Replace the placeholder `API_KEY` in `components/PanoraApp.tsx` if/when you integrate real APIs.
- If you want me to fully inject your original full App TSX content (exact copy), say "inject full app" and I'll add it into the components file.
