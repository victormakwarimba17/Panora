"use client";

import React, { useState, useEffect, useRef, useMemo } from 'react';
import { 
  Search, MapPin, Calendar as CalendarIcon, Users, Menu, X, Star, Heart, 
  Play, Pause, ChevronRight, ShieldCheck, Zap, Globe, ChevronDown, Mail, 
  Tent, Utensils, Waves, Mountain, Music, Camera, Briefcase, User, Minus, 
  Plus, Loader2, Lightbulb, BookOpen, Send, Check, MessageSquare, Baby, Moon, Sun, 
  Languages, Filter, ArrowUpDown, DollarSign, Clock, Hash, Zap as ZapIcon, Key, Landmark, Lock, Map
} from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

// --- CONFIGURATION & MOCK DATA ---
const API_KEY = ""; 
const MODEL = "gemini-2.5-flash-preview-09-2025"; 
const ADMIN_EMAIL = "victormakwarimba.t@gmail.com";

// --- GLOBAL TYPES ---
type ViewState = 'home' | 'explore' | 'hosting' | 'blog' | 'reviews' | 'login';
type Language = 'en' | 'sn' | 'nr' | 'fr' | 'es' | 'de' | 'pt' | 'zh' | 'ja' | 'ru' | 'ar' | 'it' | 'sw';
type Theme = 'light' | 'dark';

// --- TRANSLATIONS (13 Languages) ---
const TRANSLATIONS: Record<Language, Record<string, string>> = {
  en: { 
    heroTitle: "Stay Better. Explore Deeper.", subTitle: "Experience Zimbabwe.", search: "Search", explore: "Explore", stays: "Stays", adventures: "Adventures", login: "Sign In / Join", hosting: "Become a Host", reviews: "Reviews",
    seasonal: "Best Destinations for Every Season",
    adventuresTitle: "Adventures Around Zimbabwe",
    whyPanoraTitle: "Why Panora? Book with Confidence",
    toursTitle: "Book the Best Tours & Safaris",
    toursBody: "Panora makes exploring and booking organized adventures effortless. Whether you're looking for a luxury houseboat on Kariba or a rugged hike in Chimanimani, we streamline your booking experience.",
    fingertipsTitle: "Adventure at Your Fingertips",
    fingertipsBody: "We put Zimbabwe in your pocket. Explore thousands of trips, receive real-time updates, and manage bookings effortlessly.",
    seasonalSpring: "Spring Blossoms", seasonalSummer: "Summer Sunsets", seasonalAutumn: "Autumn Hues", seasonalWinter: "Winter Safaris",
  },
  sn: { 
    heroTitle: "Gara Zvirinani. Ongorora Zvakadzama.", subTitle: "Inzwa Zimbabwe.", search: "Tsvaga", explore: "Ongorora", stays: "Dzimba", adventures: "Zviitiko", login: "Pinda / Join", hosting: "Iva Muteveri", reviews: "Miongororo",
    seasonal: "Nzvimbo Dzakanakisisa Panguva Dzose",
    adventuresTitle: "Zviitiko Zvakapoteredza Zimbabwe",
    whyPanoraTitle: "Sei Panora? Bhuka Nechivimbo",
    toursTitle: "Bhuka Rwendo Rwakanakisisa",
    toursBody: "Panora inoita kuti kuongorora nekubhuka zviitiko zvakarongwa zvive nyore. Kunyangwe uchitsvaga imba yekutuhwina paKariba kana kufamba gomo kuChimanimani, tinoita kuti kubhuka kwako kuve nyore.",
    fingertipsTitle: "Chishongedzo Pamaoko Ako",
    fingertipsBody: "Isu tinopinza Zimbabwe muhomwe mako. Ongorora zviuru zverwendo, gamuchira zviziviso zvechinguva, uye gadzirisa mabhuku zviri nyore.",
    seasonalSpring: "Maruva eChirimo", seasonalSummer: "Kuvira Kwezuva kweZhizha", seasonalAutumn: "Mavara eKukwira", seasonalWinter: "Safari dzeChando",
  },
  nr: { 
    heroTitle: "Hlala Kuhle. Hlola Okujulile.", subTitle: "Izwa iZimbabwe.", search: "Cinga", explore: "Hlola", stays: "Izindawo", adventures: "Izigigaba", login: "Ngena / Joyina", hosting: "Bamba Iqhaza", reviews: "Ukubuyekeza",
    seasonal: "Izindawo Ezinhle Kakhulu Zesizini Zonke",
    adventuresTitle: "Izigigaba Ezizungeze iZimbabwe",
    whyPanoraTitle: "Kungani iPanora? Bhukha Ngokuqiniseka",
    toursTitle: "Bhukha AmaTours namaSafaris Ahamba Phambili",
    toursBody: "IPanora yenza ukuhlola nokubhukha izigigaba ezihleliwe kube lula. Kungakhathaliseki ukuthi ufuna indlu encane yokuntanta eKariba noma ukuhamba ngezinyawo okuqinile eChimanimani, senza ukubhukha kwakho kube lula.",
    fingertipsTitle: "Ukuvivinya Umzimba Kusezandleni Zakho",
    fingertipsBody: "Sibeka iZimbabwe ephaketheni lakho. Hlola izinkulungwane zokuhamba, thola izibuyekezo zesikhathi sangempela, futhi uphathe ukubhuka kalula.",
    seasonalSpring: "Izimbali Zasentwasahlobo", seasonalSummer: "Ukushona Kwelanga Kwasehlobo", seasonalAutumn: "Imibala Yokwindla", seasonalWinter: "AmaSafaris Ebusika",
  },
  fr: { heroTitle: "Séjournez Mieux. Explorez Plus.", subTitle: "Découvrez le Zimbabwe.", search: "Rechercher", explore: "Explorer", stays: "Séjours", adventures: "Aventures", login: "Connexion / Adhérer", hosting: "Devenir Hôte", reviews: "Avis", seasonal: "Meilleures destinations saisonnières", adventuresTitle: "Aventures au Zimbabwe", whyPanoraTitle: "Pourquoi Panora ? Réservez en toute confiance", toursTitle: "Réservez les meilleurs circuits et safaris", toursBody: "Panora facilite la découverte et la réservation d'aventures organisées. Que vous recherchiez une péniche de luxe sur Kariba ou une randonnée difficile à Chimanimani, nous simplifions votre expérience de réservation.", fingertipsTitle: "L'aventure à portée de main", fingertipsBody: "Nous mettons le Zimbabwe dans votre poche. Explorez des milliers de voyages, recevez des mises à jour en temps réel et gérez vos réservations sans effort.", seasonalSpring: "Floraisons de Printemps", seasonalSummer: "Couchers de soleil d'été", seasonalAutumn: "Teintes d'Automne", seasonalWinter: "Safaris d'Hiver" },
  es: { heroTitle: "Alójate Mejor. Explora Más.", subTitle: "Vive Zimbabue.", search: "Buscar", explore: "Explorar", stays: "Estancias", adventures: "Aventuras", login: "Entrar / Unirse", hosting: "Ser Anfitrión", reviews: "Reseñas", seasonal: "Mejores destinos por temporada", adventuresTitle: "Aventuras en Zimbabue", whyPanoraTitle: "¿Por qué Panora? Reserva con confianza", toursTitle: "Reserva los mejores tours y safaris", toursBody: "Panora hace que explorar y reservar aventuras organizadas sea sencillo. Ya sea que esté buscando una casa flotante de lujo en Kariba o una caminata por Chimanimani, simplificamos su experiencia de reserva.", fingertipsTitle: "Aventura a tu alcance", fingertipsBody: "Ponemos Zimbabue en tu bolsillo. Explora miles de viajes, recibe actualizaciones en tiempo real y gestiona reservas sin esfuerzo.", seasonalSpring: "Flores de Primavera", seasonalSummer: "Atardeceres de Verano", seasonalAutumn: "Tonos de Otoño", seasonalWinter: "Safaris de Invierno" },
  de: { heroTitle: "Besser Übernachten.", subTitle: "Erlebe Simbabwe.", search: "Suchen", explore: "Entdecken", stays: "Aufenthalte", adventures: "Abenteuer", login: "Anmelden / Beitreten", hosting: "Gastgeber werden", reviews: "Bewertungen", seasonal: "Beste Reiseziele für jede Jahreszeit", adventuresTitle: "Abenteuer in Simbabwe", whyPanoraTitle: "Warum Panora? Buchen Sie mit Vertrauen", toursTitle: "Buchen Sie die besten Touren & Safaris", toursBody: "Panora macht das Erkunden und Buchen organisierter Abenteuer mühelos. Egal, ob Sie nach einem luxuriösen Hausboot auf Kariba oder einer anspruchsvollen Wanderung in Chimanimani suchen, wir optimieren Ihr Buchungserlebnis.", fingertipsTitle: "Abenteuer auf Knopfdruck", fingertipsBody: "Wir stecken Simbabwe in Ihre Tasche. Entdecken Sie Tausende von Reisen, erhalten Sie Echtzeit-Updates und verwalten Sie Buchungen mühelos.", seasonalSpring: "Frühlingsblüten", seasonalSummer: "Sommer-Sonnenuntergänge", seasonalAutumn: "Herbstfarben", seasonalWinter: "Winter-Safaris" },
  pt: { heroTitle: "Fique Melhor. Explore Mais.", subTitle: "Experimente o Zimbábue.", search: "Pesquisar", explore: "Explorar", stays: "Estadias", adventures: "Aventuras", login: "Entrar / Juntar-se", hosting: "Ser Anfitrião", reviews: "Avaliações", seasonal: "Melhores destinos para cada estação", adventuresTitle: "Aventuras ao redor do Zimbábue", whyPanoraTitle: "Por que Panora? Reserve com confiança", toursTitle: "Reserve os melhores passeios e safáris", toursBody: "A Panora torna a exploração e a reserva de aventuras organizadas sem esforço. Esteja você procurando uma luxuosa casa flutuante em Kariba ou uma caminhada difícil em Chimanimani, simplificamos sua experiência de reserva.", fingertipsTitle: "Aventura ao Seu Alcance", fingertipsBody: "Colocamos o Zimbábue no seu bolso. Explore milhares de viagens, receba atualizações em tempo real e gerencie reservas sem esforço.", seasonalSpring: "Flores da Primavera", seasonalSummer: "Pôr do Sol de Verão", seasonalAutumn: "Tons de Outono", seasonalWinter: "Safáris de Inverno" },
  zh: { heroTitle: "更好的住宿，更深入的探索。", subTitle: "体验津巴布韦。", search: "搜索", explore: "探索", stays: "住宿", adventures: "冒险", login: "登录 / 加入", hosting: "成为房东", reviews: "评论", seasonal: "每个季节的最佳目的地", adventuresTitle: "津巴布韦周边的冒险", whyPanoraTitle: "为什么选择 Panora？放心预订", toursTitle: "预订最佳旅游和狩猎之旅", toursBody: "Panora 使探索和预订有组织的冒险变得毫不费力。无论您是在卡里巴寻找豪华船屋，还是在奇马尼马尼进行崎岖的徒步旅行，我们都会简化您的预订体验。", fingertipsTitle: "触手可及的冒险", fingertipsBody: "我们将津巴布韦放在您的口袋里。探索数千次旅行，接收实时更新，并轻松管理预订。", seasonalSpring: "春日花开", seasonalSummer: "夏日日落", seasonalAutumn: "秋日色调", seasonalWinter: "冬季狩猎" },
  ja: { heroTitle: "より良い滞在。より深い探検。", subTitle: "ジンバブエを体験。", search: "検索", explore: "探索", stays: "滞在", adventures: "冒険", login: "ログイン / 参加", hosting: "ホストになる", reviews: "レビュー", seasonal: "季節ごとの最高の目的地", adventuresTitle: "ジンバブエ周辺の冒険", whyPanoraTitle: "パノラマを選ぶ理由? 自信を持って予約", toursTitle: "最高のツアーとサファリを予約", toursBody: "パノラマは、組織化された冒険の探索と予約を楽にします。カリバの豪華なハウスボートを探している場合でも、チマニマニでの険しいハイキングを探している場合でも、予約体験を合理化します。", fingertipsTitle: "指先での冒険", fingertipsBody: "私たちはジンバブエをあなたのポケットに入れます。何千もの旅行を探索し、リアルタイムの更新情報を受け取り、予約を簡単に管理できます。", seasonalSpring: "春の開花", seasonalSummer: "夏の夕焼け", seasonalAutumn: "秋の色", seasonalWinter: "冬のサファリ" },
  ru: { heroTitle: "Живи Лучше. Исследуй Глубже.", subTitle: "Почувствуй Зимбабве.", search: "Поиск", explore: "Обзор", stays: "Жилье", adventures: "Приключения", login: "Войти / Присоединиться", hosting: "Стать хозяином", reviews: "Отзывы", seasonal: "Лучшие направления для каждого сезона", adventuresTitle: "Приключения по Зимбабве", whyPanoraTitle: "Почему Panora? Бронируйте с уверенностью", toursTitle: "Забронируйте лучшие туры и сафари", toursBody: "Panora делает поиск и бронирование организованных приключений легким. Независимо от того, ищете ли вы роскошный плавучий дом на Карибе или сложный поход в Чиманимани, мы упрощаем процесс бронирования.", fingertipsTitle: "Приключение на кончиках пальцев", fingertipsBody: "Мы помещаем Зимбабве в ваш карман. Исследуйте тысячи поездок, получайте обновления в реальном времени и управляйте бронированиями без усилий.", seasonalSpring: "Весеннее цветение", seasonalSummer: "Летние закаты", seasonalAutumn: "Осенние оттенки", seasonalWinter: "Зимние сафари" },
  ar: { heroTitle: "إقامة أفضل. استكشاف أعمق.", subTitle: "جرب زيمبابوي.", search: "بحث", explore: "استكشف", stays: "إقامات", adventures: "مغامرات", login: "تسجيل الدخول / انضمام", hosting: "كن مضيفًا", reviews: "المراجعات", seasonal: "أفضل الوجهات لكل موسم", adventuresTitle: "مغامرات حول زيمبابوي", whyPanoraTitle: "لماذا بانورا؟ احجز بثقة", toursTitle: "احجز أفضل الجولات ورحلات السفاري", toursBody: "تجعل بانورا استكشاف وحجز المغامرات المنظمة أمرًا سهلاً. سواء كنت تبحث عن منزل عائم فاخر في كاريبا أو رحلة شاقة في شيماني ماني، فإننا نبسط تجربة الحجز الخاصة بك.", fingertipsTitle: "المغامرة في متناول يدك", fingertipsBody: "نضع زيمبابوي في جيبك. استكشف آلاف الرحلات، واحصل على تحديثات في الوقت الفعلي، وقم بإدارة الحجوزات دون عناء.", seasonalSpring: "أزهار الربيع", seasonalSummer: "غروب الشمس الصيفي", seasonalAutumn: "ألوان الخريف", seasonalWinter: "رحلات السفاري الشتوية" },
  it: { heroTitle: "Soggiorna Meglio.", subTitle: "Vivi lo Zimbabwe.", search: "Cerca", explore: "Esplora", stays: "Soggiorni", adventures: "Avventure", login: "Accedi / Iscriviti", hosting: "Diventa Host", reviews: "Recensioni", seasonal: "Le migliori destinazioni per ogni stagione", adventuresTitle: "Avventure in Zimbabwe", whyPanoraTitle: "Perché Panora? Prenota con fiducia", toursTitle: "Prenota i migliori tour e safari", toursBody: "Panora rende l'esplorazione e la prenotazione di avventure organizzate senza sforzo. Che tu stia cercando una lussuosa casa galleggiante a Kariba o un'escursione impegnativa a Chimanimani, semplifichiamo la tua esperienza di prenotazione.", fingertipsTitle: "Avventura a portata di mano", fingertipsBody: "Mettiamo lo Zimbabwe in tasca. Esplora migliaia di viaggi, ricevi aggiornamenti in tempo reale e gestisci le prenotazioni senza sforzo.", seasonalSpring: "Fioriture Primaverili", seasonalSummer: "Tramonti Estivi", seasonalAutumn: "Tonalità Autunnali", seasonalWinter: "Safari Invernali" },
  sw: { heroTitle: "Kaa Vizuri. Chunguza Zaidi.", subTitle: "Furahia Zimbabwe.", search: "Tafuta", explore: "Gundua", stays: "Makazi", adventures: "Matukio", login: "Ingia / Jiunge", hosting: "Kuwa Mwenyeji", reviews: "Maoni", seasonal: "Maeneo Bora kwa Kila Msimu", adventuresTitle: "Matukio Karibu na Zimbabwe", whyPanoraTitle: "Kwa nini Panora? Weka nafasi kwa ujasiri", toursTitle: "Weka nafasi kwa Ziara na Safari Bora", toursBody: "Panora hufanya kuchunguza na kuweka nafasi ya matukio yaliyopangwa kuwa rahisi. Iwe unatafuta nyumba ya kifahari ya mashua huko Kariba au safari ngumu ya kupanda mlima huko Chimanimani, tunarahisisha uzoefu wako wa kuweka nafasi.", fingertipsTitle: "Tukio Mikononi Mwako", fingertipsBody: "Tunaweka Zimbabwe mfukoni mwako. Chunguza maelfu ya safari, pokea masasisho ya wakati halisi, na udhibiti nafasi kwa urahisi.", seasonalSpring: "Maua ya Spring", seasonalSummer: "Machweo ya Majira ya joto", seasonalAutumn: "Rangi za Vuli", seasonalWinter: "Safari za Majira ya baridi" },
  // Placeholder translations for other languages for completeness
  // Note: These must be updated by the user for perfect localization.
  'it': { ...TRANSLATIONS['en'] }, 'pt': { ...TRANSLATIONS['en'] }, 'de': { ...TRANSLATIONS['en'] }, 'fr': { ...TRANSLATIONS['en'] }, 'es': { ...TRANSLATIONS['en'] }, 'zh': { ...TRANSLATIONS['en'] }, 'ja': { ...TRANSLATIONS['en'] }, 'ru': { ...TRANSLATIONS['en'] }, 'ar': { ...TRANSLATIONS['en'] },
};

const LANGUAGES: { code: Language; label: string; flag: string }[] = [
  { code: 'en', label: 'English', flag: '🇬🇧' },
  { code: 'sn', label: 'Shona', flag: '🇿🇼' },
  { code: 'nr', label: 'Ndebele', flag: '🇿🇼' },
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  { code: 'pt', label: 'Português', flag: '🇵🇹' },
  { code: 'zh', label: '中文', flag: '🇨🇳' },
  { code: 'ja', label: '日本語', flag: '🇯🇵' },
  { code: 'ru', label: 'Русский', flag: '🇷🇺' },
  { code: 'ar', label: 'العربية', flag: '🇸🇦' },
  { code: 'it', label: 'Italiano', flag: '🇮🇹' },
  { code: 'sw', label: 'Swahili', flag: '🇹🇿' },
];

// --- MOCK DATABASE ---
const PROVINCES = ["Harare", "Bulawayo", "Manicaland", "Mashonaland Central", "Mashonaland East", "Mashonaland West", "Masvingo", "Matabeleland North", "Matabeleland South", "Midlands"];
const ADVENTURE_TYPES = ["Safari & Game Drives", "Hiking & Trekking", "Water Sports", "Cultural Tours", "Houseboat Cruises", "Historical Sites"];

const LISTINGS_DB = [
  { id: 1, title: "The Residency at Leopard Rock", province: "Manicaland", location: "Vumba Mountains", price: 180, rating: 4.92, image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1000", category: "Resorts", type: "stay", amenities: ["Wifi", "Pool", "Spa"], isOpen: true },
  { id: 2, title: "Zambezi River Eco-Lodge", province: "Matabeleland North", location: "Victoria Falls", price: 320, rating: 4.98, image: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&q=80&w=1000", category: "Camps", type: "stay", amenities: ["Wifi", "Safari", "River View"], isOpen: true },
  { id: 3, title: "Amanzi Restaurant Deck", province: "Harare", location: "Harare", price: 45, rating: 4.85, image: "https://images.unsplash.com/photo-1517248135467-4c7edcad34c4?auto=format&fit=crop&q=80&w=1000", category: "Restaurants", type: "culinary", amenities: ["Bar", "Live Music"], isOpen: true },
  { id: 4, title: "Granite Stone Camp", province: "Matabeleland South", location: "Matobo Hills", price: 150, rating: 4.95, image: "https://images.unsplash.com/photo-1510798831971-661eb04b3739?auto=format&fit=crop&q=80&w=1000", category: "Camps", type: "camping", amenities: ["Hiking", "Fireplace"], isOpen: false },
  { id: 5, title: "Kariba Houseboat Luxury", province: "Mashonaland West", location: "Lake Kariba", price: 400, rating: 4.90, image: "https://images.unsplash.com/photo-1544551763-46a8e3d69958?auto=format&fit=crop&q=80&w=1000", category: "Houseboats", type: "cruise", amenities: ["Chef", "Fishing"], isOpen: true },
  { id: 6, title: "Nyanga Pine Cabin", province: "Manicaland", location: "Nyanga", price: 90, rating: 4.75, image: "https://images.unsplash.com/photo-1449156493391-d2cfa28e468b?auto=format&fit=crop&q=80&w=1000", category: "Picnic Areas", type: "stay", amenities: ["Self Catering", "Mountain View"], isOpen: true },
  { id: 7, title: "Hwange Safari Suites", province: "Matabeleland North", location: "Hwange", price: 250, rating: 4.88, image: "https://images.unsplash.com/photo-1493246507139-91e8fad9978e?auto=format&fit=crop&q=80&w=1000", category: "Camps", type: "stay", amenities: ["Game Drive", "Pool"], isOpen: true },
  { id: 8, title: "Great Zimbabwe Hotel", province: "Masvingo", location: "Masvingo", price: 120, rating: 4.60, image: "https://images.unsplash.com/photo-1566073771259-6a8506099945?auto=format&fit=crop&q=80&w=1000", category: "Resorts", type: "stay", amenities: ["History Tour", "Wifi"], isOpen: true },
];

// --- MAIN COMPONENT ---
export default function App() {
  // Global State
  const [view, setView] = useState<ViewState>('home');
  const [theme, setTheme] = useState<Theme>('light');
  const [lang, setLang] = useState<Language>('en');
  const [searchParams, setSearchParams] = useState<any>({});
  
  // Apply Theme
  useEffect(() => {
    if (theme === 'dark') {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [theme]);

  // Navigation Handler
  const navigate = (newView: ViewState, params?: any) => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
    if (params) setSearchParams(params);
    setView(newView);
  };

  return (
    <div className={`min-h-screen font-sans transition-colors duration-300 ${theme === 'dark' ? 'bg-slate-950 text-white' : 'bg-[#FAFAF9] text-slate-900'}`}>
      <Navbar 
        navigate={navigate} 
        theme={theme} 
        setTheme={setTheme} 
        lang={lang} 
        setLang={setLang} 
      />
      
      {view === 'home' && <Home navigate={navigate} lang={lang} />}
      {view === 'explore' && <Explore navigate={navigate} lang={lang} searchParams={searchParams} />}
      {view === 'login' && <Login lang={lang} navigate={navigate} />}
      {view === 'reviews' && <Reviews lang={lang} />}
      
      <Footer lang={lang} navigate={navigate} />
    </div>
  );
}

// --- NAVBAR COMPONENT (With Theme & Lang) ---
const Navbar = ({ navigate, theme, setTheme, lang, setLang }: any) => {
  const [scrolled, setScrolled] = useState(false);
  const [activeDropdown, setActiveDropdown] = useState<string | null>(null);
  const [langMenuOpen, setLangMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 50);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const t = TRANSLATIONS[lang];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled || activeDropdown ? 'bg-white/95 dark:bg-slate-900/95 backdrop-blur-md shadow-lg py-3 text-slate-900 dark:text-white' : 'bg-transparent py-5 text-white'
    }`}>
      <div className="max-w-7xl mx-auto px-6 flex justify-between items-center relative">
        <motion.div 
          onClick={() => navigate('home')}
          className={`font-bold text-2xl tracking-tighter cursor-pointer z-50 flex items-center transition-colors ${scrolled || activeDropdown ? 'text-slate-900 dark:text-white' : 'text-white'}`}
          whileHover={{ scale: 1.05 }}
        >
          PANORA<span className="text-amber-500">.</span>
        </motion.div>

        <div className="hidden lg:flex space-x-8 font-medium h-full items-center">
          <div className="relative group h-full flex items-center cursor-pointer" onMouseEnter={() => setActiveDropdown('destinations')} onMouseLeave={() => setActiveDropdown(null)}>
            <button className={`flex items-center space-x-1 hover:text-amber-500 transition-colors py-2 ${scrolled || activeDropdown === 'destinations' ? 'text-slate-700 dark:text-white' : 'text-white'}`}>
              <span>{t.explore}</span><ChevronDown size={16} />
            </button>
          </div>
          <div className="relative group h-full flex items-center cursor-pointer" onMouseEnter={() => setActiveDropdown('adventures')} onMouseLeave={() => setActiveDropdown(null)}>
            <button className={`flex items-center space-x-1 hover:text-amber-500 transition-colors py-2 ${scrolled || activeDropdown === 'adventures' ? 'text-slate-700 dark:text-white' : 'text-white'}`}>
              <span>{t.adventures}</span><ChevronDown size={16} />
            </button>
          </div>
          <button onClick={() => navigate('reviews')} className={`hover:text-amber-500 transition-colors ${scrolled ? 'text-slate-700 dark:text-white' : 'text-white'}`}>{t.reviews}</button>
          <a href="#" className={`hover:text-amber-500 transition-colors ${scrolled ? 'text-slate-700 dark:text-white' : 'text-white'}`}>Blog</a>
        </div>

        <div className="hidden lg:flex items-center space-x-4">
          {/* Theme Toggle */}
          <button 
            onClick={() => setTheme(theme === 'light' ? 'dark' : 'light')}
            className={`p-2 rounded-full transition-colors ${scrolled ? 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-900 dark:text-white' : 'text-white hover:bg-white/20'}`}
          >
            {theme === 'light' ? <Moon size={20} /> : <Sun size={20} className="text-amber-400" />}
          </button>

          {/* Language Toggle */}
          <div className="relative">
            <button 
              onClick={() => setLangMenuOpen(!langMenuOpen)}
              className={`p-2 rounded-full transition-colors flex items-center gap-1 ${scrolled ? 'hover:bg-slate-100 dark:hover:bg-slate-800 text-slate-900 dark:text-white' : 'text-white hover:bg-white/20'}`}
            >
              <Languages size={20} />
              <span className="text-xs font-bold uppercase">{lang}</span>
            </button>
            {langMenuOpen && (
              <div className="absolute top-full right-0 mt-2 w-48 bg-white dark:bg-slate-800 shadow-xl rounded-xl border border-slate-100 dark:border-slate-700 overflow-hidden max-h-64 overflow-y-auto z-50">
                {LANGUAGES.map((l) => (
                  <button 
                    key={l.code}
                    onClick={() => { setLang(l.code); setLangMenuOpen(false); }}
                    className="w-full text-left px-4 py-3 hover:bg-slate-50 dark:hover:bg-slate-700 flex items-center gap-3 text-sm text-slate-700 dark:text-slate-200"
                  >
                    <span>{l.flag}</span>
                    <span>{l.label}</span>
                    {lang === l.code && <Check size={14} className="ml-auto text-amber-500" />}
                  </button>
                ))}
              </div>
            )}
          </div>

          <button onClick={() => navigate('login')} className="bg-amber-500 hover:bg-amber-600 text-white px-5 py-2.5 rounded-full font-semibold transition-transform hover:scale-105 shadow-lg flex items-center space-x-2">
            <User size={18} />
            <span>{t.login}</span>
          </button>
        </div>

        {/* Mega Menus */}
        <AnimatePresence>
          {activeDropdown === 'destinations' && (
            <motion.div
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
              className="absolute top-full left-0 w-full bg-white dark:bg-slate-900 shadow-xl rounded-b-2xl border-t border-slate-100 dark:border-slate-800 overflow-hidden"
            >
              <div className="max-w-7xl mx-auto p-8 grid grid-cols-4 gap-6">
                <div className="col-span-1 bg-slate-50 dark:bg-slate-800 p-6 rounded-xl">
                  <h3 className="font-bold text-lg mb-2 text-slate-900 dark:text-white">{t.explore} Zimbabwe</h3>
                  <button onClick={() => { navigate('explore'); setActiveDropdown(null); }} className="mt-4 w-full text-center bg-amber-500 text-white px-4 py-2 rounded-lg font-semibold flex items-center justify-center space-x-2 hover:bg-amber-600 transition-colors">
                    <Globe size={16} /><span>View All Regions</span>
                  </button>
                </div>
                <div className="col-span-3 grid grid-cols-3 gap-y-3 gap-x-6">
                  {PROVINCES.map((place) => (
                    <button key={place} onClick={() => { navigate('explore', { province: place }); setActiveDropdown(null); }} className="text-left text-slate-600 dark:text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 text-sm font-medium">
                      {place}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}

          {activeDropdown === 'adventures' && (
            <motion.div
              initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: 10 }}
              className="absolute top-full left-0 w-full bg-white dark:bg-slate-900 shadow-xl rounded-b-2xl border-t border-slate-100 dark:border-slate-800 overflow-hidden"
            >
              <div className="max-w-7xl mx-auto p-8 grid grid-cols-4 gap-6">
                <div className="col-span-1 bg-slate-50 dark:bg-slate-800 p-6 rounded-xl">
                  <h3 className="font-bold text-lg mb-2 text-slate-900 dark:text-white">Adventure Categories</h3>
                  <p className="text-sm text-slate-500 dark:text-slate-400">Find tours, safaris, and activities.</p>
                </div>
                <div className="col-span-3 grid grid-cols-3 gap-y-3 gap-x-6">
                  {ADVENTURE_TYPES.map((type) => (
                    <button key={type} onClick={() => { navigate('explore', { category: type }); setActiveDropdown(null); }} className="text-left text-slate-600 dark:text-slate-400 hover:text-amber-600 dark:hover:text-amber-400 text-sm font-medium">
                      {type}
                    </button>
                  ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </nav>
  );
};

// --- HOME PAGE COMPONENT ---
const Home = ({ navigate, lang }: any) => {
  const t = TRANSLATIONS[lang];
  const aiPlannerRef = useRef<HTMLElement>(null);
  
  const scrollToAIPlanner = () => {
    aiPlannerRef.current?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <main>
      {/* HERO SECTION */}
      <div className="relative h-[95vh] w-full overflow-hidden bg-slate-900">
        <video autoPlay muted loop playsInline poster="https://images.unsplash.com/photo-1547471080-7cc2caa01a7e" className="absolute inset-0 w-full h-full object-cover opacity-60">
          <source src="https://assets.mixkit.co/videos/preview/mixkit-aerial-view-of-victoria-falls-4266-large.mp4" type="video/mp4" />
        </video>
        <div className="absolute inset-0 bg-gradient-to-b from-black/60 via-transparent to-slate-950" />
        
        <div className="relative z-10 h-full flex flex-col justify-center items-center px-4 text-center pt-20">
          <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-4xl md:text-6xl lg:text-7xl font-bold text-white tracking-tight mb-6 max-w-5xl">
            {t.heroTitle} <br /><span className="text-amber-400">{t.subTitle}</span>
          </motion.h1>
          <div className="w-full max-w-5xl">
            <SearchBar onSearch={(params: any) => navigate('explore', params)} onGetInsightClick={scrollToAIPlanner} t={t} />
          </div>
        </div>
      </div>

      {/* FEATURED CAROUSEL */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <div className="flex justify-between items-end mb-8">
          <div>
            <h2 className="text-3xl font-bold mb-2 dark:text-white">Unforgettable Stays</h2>
            <p className="text-slate-500 dark:text-slate-400">From hidden gems to iconic destinations.</p>
          </div>
          <button onClick={() => navigate('explore')} className="flex items-center space-x-1 font-semibold text-slate-900 dark:text-amber-400 hover:text-amber-600 transition-colors">
            <span>View all</span><ChevronRight size={18} />
          </button>
        </div>
        <div className="flex overflow-x-auto snap-x snap-mandatory space-x-6 pb-8 scrollbar-hide">
          {LISTINGS_DB.slice(0, 5).map(listing => (
            <ListingCard key={listing.id} data={listing} />
          ))}
        </div>
      </section>

      {/* WHY PANORA? - Book with Confidence */}
      <section className="bg-slate-100 dark:bg-slate-900 py-20">
        <div className="max-w-7xl mx-auto px-6">
          <h2 className="text-4xl font-extrabold text-center mb-12 dark:text-white">{t.whyPanoraTitle}</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <FeatureCard icon={<ShieldCheck size={40} className="text-amber-500" />} title="Verified Hosts" description="Every host and property is vetted for safety, security, and quality assurance standards." />
            <FeatureCard icon={<Lock size={40} className="text-amber-500" />} title="Secure Payments" description="All transactions are encrypted and processed through trusted, international payment gateways." />
            <FeatureCard icon={<MessageSquare size={40} className="text-amber-500" />} title="24/7 Support" description="Our dedicated local team is available around the clock to assist with bookings, changes, or emergencies." />
          </div>
        </div>
      </section>

      {/* TOURS & SAFARIS - Adventure at Your Fingertips */}
      <section className="max-w-7xl mx-auto px-6 py-20 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
        <div>
          <h2 className="text-4xl font-bold mb-4 dark:text-white">{t.toursTitle}</h2>
          <p className="text-slate-600 dark:text-slate-400 text-lg mb-8">{t.toursBody}</p>
          <div className="flex items-center space-x-4">
            <button onClick={() => navigate('explore', { category: 'Safari' })} className="bg-amber-500 hover:bg-amber-600 text-white px-8 py-3 rounded-full font-bold transition-all shadow-md">
              Find Adventures
            </button>
            <button className="flex items-center space-x-2 text-slate-600 dark:text-slate-300 hover:text-amber-500 transition-colors font-medium">
              <Play size={20} /><span>Watch Promo</span>
            </button>
          </div>
        </div>
        <div className="space-y-6">
          <FeatureBlock icon={<Map size={24} className="text-amber-500" />} title={t.fingertipsTitle} body={t.fingertipsBody} />
          <FeatureBlock icon={<ZapIcon size={24} className="text-amber-500" />} title="Instant Booking" body="Confirm your tour instantly and receive all documents via email." />
          <FeatureBlock icon={<CalendarIcon size={24} className="text-amber-500" />} title="Flexible Cancellation" body="Change or cancel most bookings up to 48 hours before your trip." />
        </div>
      </section>
      
      {/* SEASONAL DESTINATIONS */}
      <section className="max-w-7xl mx-auto px-6 py-20">
        <h2 className="text-4xl font-bold text-center mb-12 dark:text-white">{t.seasonal}</h2>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
          <SeasonalCard title={t.seasonalSpring} location="Eastern Highlands" icon={<Tent size={32} />} color="text-green-500" />
          <SeasonalCard title={t.seasonalSummer} location="Lake Kariba" icon={<Waves size={32} />} color="text-sky-500" />
          <SeasonalCard title={t.seasonalAutumn} location="Matobo Hills" icon={<Mountain size={32} />} color="text-red-500" />
          <SeasonalCard title={t.seasonalWinter} location="Hwange National Park" icon={<Camera size={32} />} color="text-indigo-500" />
        </div>
      </section>

      <AITripPlanner ref={aiPlannerRef} />
    </main>
  );
};

// --- REUSABLE COMPONENT: SEARCH BAR ---
const SearchBar = ({ onSearch, onGetInsightClick, t }: any) => {
  const [location, setLocation] = useState('');
  const [adults, setAdults] = useState(1);
  const [children, setChildren] = useState(0);
  const [checkIn, setCheckIn] = useState('');
  const [checkOut, setCheckOut] = useState('');
  const [showGuestPopup, setShowGuestPopup] = useState(false);
  const [showLocationSuggestions, setShowLocationSuggestions] = useState(false);

  const today = new Date().toISOString().split('T')[0];
  const searchBarRef = useRef<HTMLDivElement>(null);

  const handleSearchClick = () => {
    onSearch({ location, adults, children, checkIn, checkOut });
  };

  const allLocations = useMemo(() => {
    const locations = new Set<string>();
    LISTINGS_DB.forEach(l => {
      locations.add(l.location);
      locations.add(l.province);
    });
    return Array.from(locations).sort();
  }, []);

  const locationSuggestions = useMemo(() => {
    if (!location) return allLocations.slice(0, 5);
    return allLocations.filter(loc => 
      loc.toLowerCase().includes(location.toLowerCase())
    ).slice(0, 5);
  }, [location, allLocations]);

  // Click outside handler for dropdowns
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (searchBarRef.current && !searchBarRef.current.contains(event.target as Node)) {
        setShowGuestPopup(false);
        setShowLocationSuggestions(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);


  return (
    <div className="relative z-40" ref={searchBarRef}>
      <div className="bg-white dark:bg-slate-800 rounded-[2rem] p-2 shadow-[0_6px_18px_rgba(10,10,10,0.15)] flex flex-col md:flex-row items-center divide-y md:divide-y-0 md:divide-x divide-slate-100 dark:divide-slate-700 relative">
        {/* WHERE Input with Suggestions */}
        <div className="flex-1 px-6 py-3 w-full relative">
          <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide">Where</label>
          <div className="flex items-center">
            <MapPin size={14} className="text-slate-400 mr-2" />
            <input 
              type="text" 
              value={location} 
              onChange={(e) => setLocation(e.target.value)} 
              onFocus={() => setShowLocationSuggestions(true)}
              placeholder={t.search + " destinations"} 
              className="w-full bg-transparent outline-none text-slate-700 dark:text-white placeholder-slate-400 text-sm font-medium" 
            />
          </div>
          {showLocationSuggestions && locationSuggestions.length > 0 && (
            <div className="absolute top-full left-0 mt-3 w-full bg-white dark:bg-slate-700 shadow-xl rounded-xl border border-slate-100 dark:border-slate-600 overflow-hidden z-50">
              {locationSuggestions.map((suggestion) => (
                <button 
                  key={suggestion}
                  onClick={() => { setLocation(suggestion); setShowLocationSuggestions(false); }}
                  className="w-full text-left px-4 py-3 hover:bg-amber-50 dark:hover:bg-slate-600 flex items-center gap-3 text-sm text-slate-700 dark:text-slate-200"
                >
                  <MapPin size={16} className="text-amber-500" />
                  <span>{suggestion}</span>
                </button>
              ))}
            </div>
          )}
        </div>
        
        {/* Dates and Guests */}
        <div className="px-6 py-3 w-full md:w-auto">
          <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide">Check In</label>
          <input type="date" min={today} value={checkIn} onChange={(e) => setCheckIn(e.target.value)} className="bg-transparent text-sm text-slate-600 dark:text-slate-300 outline-none font-medium w-full md:w-32 cursor-pointer dark:[color-scheme:dark]" />
        </div>
        <div className="px-6 py-3 w-full md:w-auto">
          <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide">Check Out</label>
          <input type="date" min={checkIn || today} value={checkOut} onChange={(e) => setCheckOut(e.target.value)} className="bg-transparent text-sm text-slate-600 dark:text-slate-300 outline-none font-medium w-full md:w-32 cursor-pointer dark:[color-scheme:dark]" />
        </div>
        
        {/* Guests Input with Popup */}
        <div className="px-6 py-3 w-full md:w-auto relative cursor-pointer" onClick={() => setShowGuestPopup(!showGuestPopup)}>
          <label className="block text-xs font-bold text-slate-800 dark:text-slate-200 uppercase tracking-wide">Who</label>
          <div className="flex items-center">
            <Users size={14} className="text-slate-400 mr-2" />
            <span className="text-sm text-slate-600 dark:text-slate-300 font-medium whitespace-nowrap">{adults + children} Guests</span>
          </div>
          {showGuestPopup && (
            <div className="absolute top-full right-0 w-72 bg-white dark:bg-slate-800 shadow-xl rounded-2xl mt-4 p-4 border border-slate-100 dark:border-slate-700 z-50 cursor-auto" onClick={(e) => e.stopPropagation()}>
              <div className="flex justify-between items-center mb-4">
                <div><div className="font-bold text-slate-900 dark:text-white">Adults</div><div className="text-xs text-slate-500">Ages 13+</div></div>
                <div className="flex items-center space-x-3">
                  <button onClick={() => setAdults(Math.max(1, adults - 1))} className="p-1 rounded-full border border-slate-300 dark:border-slate-600 hover:border-amber-500 dark:text-white"><Minus size={16} /></button>
                  <span className="font-bold w-4 text-center dark:text-white">{adults}</span>
                  <button onClick={() => setAdults(adults + 1)} className="p-1 rounded-full border border-slate-300 dark:border-slate-600 hover:border-amber-500 dark:text-white"><Plus size={16} /></button>
                </div>
              </div>
              <div className="flex justify-between items-center mb-4">
                <div><div className="font-bold text-slate-900 dark:text-white">Children</div><div className="text-xs text-slate-500">Ages 2-12</div></div>
                <div className="flex items-center space-x-3">
                  <button onClick={() => setChildren(Math.max(0, children - 1))} className="p-1 rounded-full border border-slate-300 dark:border-slate-600 hover:border-amber-500 dark:text-white"><Minus size={16} /></button>
                  <span className="font-bold w-4 text-center dark:text-white">{children}</span>
                  <button onClick={() => setChildren(children + 1)} className="p-1 rounded-full border border-slate-300 dark:border-slate-600 hover:border-amber-500 dark:text-white"><Plus size={16} /></button>
                </div>
              </div>
              <button onClick={(e) => { e.stopPropagation(); setShowGuestPopup(false); }} className="w-full text-center text-amber-600 font-bold text-sm hover:underline">Done</button>
            </div>
          )}
        </div>
        
        {/* Search Button */}
        <div className="p-2 w-full md:w-auto">
          <button onClick={handleSearchClick} className="w-full md:w-auto bg-amber-500 hover:bg-amber-600 text-white p-4 rounded-full transition-all duration-200 hover:scale-105 shadow-md flex items-center justify-center space-x-2">
            <Search size={20} strokeWidth={3} />
            <span className="md:hidden font-bold">{t.search}</span>
          </button>
        </div>
      </div>
      <div className="flex justify-center mt-6">
        <button onClick={onGetInsightClick} className="bg-white/90 dark:bg-slate-800/90 backdrop-blur text-slate-900 dark:text-white border border-white/20 px-6 py-2 rounded-full font-medium text-sm hover:bg-white dark:hover:bg-slate-800 transition-colors flex items-center space-x-2 shadow-lg">
          <Lightbulb size={16} className="text-amber-500" /><span>AI Travel Insight</span>
        </button>
      </div>
    </div>
  );
};

// --- REUSABLE COMPONENTS ---
const ListingCard = ({ data }: any) => {
  return (
    <div className="group cursor-pointer bg-white dark:bg-slate-900 rounded-xl overflow-hidden border border-transparent hover:border-slate-200 dark:hover:border-slate-800 transition-all">
      <div className="relative aspect-[4/3] overflow-hidden bg-slate-200 dark:bg-slate-800">
        <img src={data.image} alt={data.title} loading="lazy" className="object-cover w-full h-full transition-transform duration-500 group-hover:scale-110" />
        <div className="absolute top-3 right-3 z-10">
          <button className="p-2 rounded-full bg-black/20 hover:bg-white/20 text-white backdrop-blur-sm transition-colors"><Heart size={18} /></button>
        </div>
        <div className="absolute top-3 left-3 z-10 flex gap-2">
          <span className="px-3 py-1 bg-white/90 dark:bg-slate-900/90 backdrop-blur-md rounded-full text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wide shadow-sm">{data.category}</span>
          <span className={`px-3 py-1 backdrop-blur-md rounded-full text-xs font-bold text-white uppercase tracking-wide shadow-sm ${data.isOpen ? 'bg-green-500/90' : 'bg-red-500/90'}`}>{data.isOpen ? 'Open' : 'Closed'}</span>
        </div>
      </div>
      <div className="p-4">
        <div className="flex justify-between items-start mb-2">
          <div>
            <div className="flex items-center space-x-1 mb-1 text-slate-500 dark:text-slate-400">
              <MapPin size={12} />
              <span className="text-xs font-bold uppercase tracking-wide">{data.province}</span>
            </div>
            <h3 className="font-bold text-lg text-slate-900 dark:text-white leading-tight group-hover:text-amber-500 transition-colors">{data.title}</h3>
            <p className="text-slate-500 dark:text-slate-400 text-sm mt-1">{data.location}</p>
          </div>
          <div className="flex items-center space-x-1 bg-slate-100 dark:bg-slate-800 px-2 py-1 rounded-md">
            <Star size={12} className="fill-amber-400 text-amber-400" />
            <span className="text-xs font-bold text-slate-900 dark:text-white">{data.rating}</span>
          </div>
        </div>
        {data.amenities && (
          <div className="flex gap-2 mb-4 flex-wrap">
            {data.amenities.map((am: string) => (
              <span key={am} className="text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 px-2 py-1 rounded-full">{am}</span>
            ))}
          </div>
        )}
        <div className="flex items-baseline space-x-1 pt-3 border-t border-slate-100 dark:border-slate-800">
          <span className="font-bold text-xl text-slate-900 dark:text-white">${data.price}</span>
          <span className="text-slate-500 text-sm">/ night</span>
        </div>
      </div>
    </div>
  );
};

const SeasonalCard = ({ title, location, icon, color }: any) => (
  <div className="bg-white dark:bg-slate-900 p-6 rounded-xl shadow-lg border border-slate-100 dark:border-slate-800 flex flex-col items-center text-center hover:shadow-xl transition-shadow cursor-pointer">
    <div className={`p-4 rounded-full bg-slate-100 dark:bg-slate-800 mb-4 ${color}`}>{icon}</div>
    <h3 className="text-xl font-bold mb-2 dark:text-white">{title}</h3>
    <p className="text-sm text-slate-500 dark:text-slate-400">{location}</p>
  </div>
);

const FeatureCard = ({ icon, title, description }: any) => (
  <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-lg border border-slate-200 dark:border-slate-700 hover:shadow-2xl transition-all">
    <div className="mb-4">{icon}</div>
    <h3 className="text-xl font-bold mb-2 dark:text-white">{title}</h3>
    <p className="text-slate-500 dark:text-slate-400 text-sm">{description}</p>
  </div>
);

const FeatureBlock = ({ icon, title, body }: any) => (
  <div className="flex space-x-4 p-4 rounded-xl bg-slate-50 dark:bg-slate-800/50">
    <div className="pt-1">{icon}</div>
    <div>
      <h4 className="font-bold dark:text-white">{title}</h4>
      <p className="text-sm text-slate-600 dark:text-slate-400 mt-1">{body}</p>
    </div>
  </div>
);


// --- EXPLORE PAGE COMPONENT (The "Perfect" Search Page) ---
const Explore = ({ navigate, lang, searchParams }: any) => {
  const [listings, setListings] = useState(LISTINGS_DB);
  const [filters, setFilters] = useState({
    priceRange: [0, 1000],
    provinces: [] as string[],
    categories: [] as string[],
    amenities: [] as string[],
    minRating: 0,
    openNow: false
  });
  const [sort, setSort] = useState('recommended');
  
  // Apply Filters Logic
  useEffect(() => {
    let result = LISTINGS_DB;

    // Filter by Province (from URL or Sidebar)
    const urlProvince = searchParams.province;
    if (urlProvince || filters.provinces.length > 0) {
      const activeProvinces = urlProvince ? [urlProvince] : filters.provinces;
      if (activeProvinces.length > 0) {
        result = result.filter(l => activeProvinces.includes(l.province));
      }
    }

    // Filter by Search Text
    if (searchParams.location) {
      const term = searchParams.location.toLowerCase();
      result = result.filter(l => l.title.toLowerCase().includes(term) || l.location.toLowerCase().includes(term));
    }

    // Filter by Category (from URL or Sidebar)
    const urlCategory = searchParams.category;
    if (urlCategory) {
       result = result.filter(l => l.category.includes(urlCategory));
    }


    // Filter by Open Now
    if (filters.openNow) {
      result = result.filter(l => l.isOpen);
    }

    // Filter by Price
    result = result.filter(l => l.price >= filters.priceRange[0] && l.price <= filters.priceRange[1]);

    // Sorting
    if (sort === 'priceAsc') result.sort((a, b) => a.price - b.price);
    if (sort === 'priceDesc') result.sort((a, b) => b.price - a.price);
    if (sort === 'rating') result.sort((a, b) => b.rating - a.rating);

    setListings([...result]);
  }, [filters, sort, searchParams]);

  const toggleFilter = (type: string, value: string) => {
    setFilters(prev => {
      const list = prev[type as keyof typeof prev] as string[];
      return {
        ...prev,
        [type]: list.includes(value) ? list.filter(i => i !== value) : [...list, value]
      };
    });
  };

  return (
    <div className="pt-24 pb-20 max-w-7xl mx-auto px-6 min-h-screen">
      
      {/* Header & Mobile Filters */}
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-8 gap-4">
        <div>
          <h1 className="text-4xl font-bold dark:text-white">Explore Zimbabwe</h1>
          <p className="text-slate-500 dark:text-slate-400 mt-1">
            {listings.length} places found {searchParams.location && `near "${searchParams.location}"`}
          </p>
        </div>
        <div className="flex items-center gap-3">
          <div className="relative">
            <select 
              value={sort} 
              onChange={(e) => setSort(e.target.value)}
              className="appearance-none bg-white dark:bg-slate-800 border border-slate-200 dark:border-slate-700 px-4 py-2.5 pr-10 rounded-lg text-sm font-medium focus:ring-2 focus:ring-amber-500 outline-none"
            >
              <option value="recommended">Recommended</option>
              <option value="priceAsc">Price: Low to High</option>
              <option value="priceDesc">Price: High to Low</option>
              <option value="rating">Top Rated</option>
            </select>
            <ArrowUpDown size={16} className="absolute right-3 top-3 text-slate-400 pointer-events-none" />
          </div>
          <button className="md:hidden p-2.5 bg-slate-900 text-white rounded-lg"><Filter size={20} /></button>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-4 gap-8">
        {/* SIDEBAR FILTERS */}
        <aside className="hidden lg:block space-y-8 h-fit sticky top-28">
          {/* Price Filter */}
          <div>
            <h3 className="font-bold mb-4 dark:text-white">Price Range</h3>
            <div className="flex items-center gap-4 text-sm text-slate-600 dark:text-slate-400 mb-2">
              <span>${filters.priceRange[0]}</span>
              <input 
                type="range" min="0" max="1000" step="50" 
                value={filters.priceRange[1]}
                onChange={(e) => setFilters({...filters, priceRange: [0, parseInt(e.target.value)]})}
                className="w-full h-1 bg-slate-200 rounded-lg appearance-none cursor-pointer accent-amber-500"
              />
              <span>${filters.priceRange[1]}+</span>
            </div>
          </div>

          {/* Open Now Toggle */}
          <div className="flex items-center justify-between">
            <span className="font-medium dark:text-slate-300">Open Now</span>
            <button 
              onClick={() => setFilters({...filters, openNow: !filters.openNow})}
              className={`w-12 h-6 rounded-full transition-colors relative ${filters.openNow ? 'bg-amber-500' : 'bg-slate-300 dark:bg-slate-700'}`}
            >
              <span className={`absolute top-1 left-1 bg-white w-4 h-4 rounded-full transition-transform ${filters.openNow ? 'translate-x-6' : ''}`} />
            </button>
          </div>

          {/* Provinces */}
          <div>
            <h3 className="font-bold mb-3 dark:text-white">Provinces</h3>
            <div className="space-y-2 max-h-48 overflow-y-auto pr-2 scrollbar-thumb-amber-500 scrollbar-track-slate-100">
              {PROVINCES.map(prov => (
                <label key={prov} className="flex items-center gap-3 cursor-pointer group">
                  <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${filters.provinces.includes(prov) ? 'bg-amber-500 border-amber-500 text-white' : 'border-slate-300 dark:border-slate-600'}`}>
                    {filters.provinces.includes(prov) && <Check size={12} />}
                  </div>
                  <input type="checkbox" className="hidden" onChange={() => toggleFilter('provinces', prov)} />
                  <span className="text-sm text-slate-600 dark:text-slate-400 group-hover:text-amber-500 transition-colors">{prov}</span>
                </label>
              ))}
            </div>
          </div>

          {/* Categories */}
          <div>
            <h3 className="font-bold mb-3 dark:text-white">Property Type</h3>
            <div className="space-y-2">
              {['Resorts', 'Camps', 'Lodges', 'Hotels', 'Houseboats'].map(cat => (
                <label key={cat} className="flex items-center gap-3 cursor-pointer group">
                  <div className={`w-5 h-5 rounded border flex items-center justify-center transition-colors ${filters.categories.includes(cat) ? 'bg-amber-500 border-amber-500 text-white' : 'border-slate-300 dark:border-slate-600'}`}>
                    {filters.categories.includes(cat) && <Check size={12} />}
                  </div>
                  <input type="checkbox" className="hidden" onChange={() => toggleFilter('categories', cat)} />
                  <span className="text-sm text-slate-600 dark:text-slate-400 group-hover:text-amber-500 transition-colors">{cat}</span>
                </label>
              ))}
            </div>
          </div>
        </aside>

        {/* LISTINGS GRID */}
        <div className="lg:col-span-3">
          {listings.length > 0 ? (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {listings.map(listing => (
                <ListingCard key={listing.id} data={listing} />
              ))}
            </div>
          ) : (
            <div className="text-center py-20">
              <div className="bg-slate-100 dark:bg-slate-800 w-20 h-20 rounded-full flex items-center justify-center mx-auto mb-4 text-slate-400">
                <Search size={32} />
              </div>
              <h3 className="text-xl font-bold dark:text-white">No matches found</h3>
              <p className="text-slate-500 mt-2">Try adjusting your filters or search for a different location.</p>
              <button onClick={() => { setFilters({ priceRange: [0, 1000], provinces: [], categories: [], amenities: [], minRating: 0, openNow: false }); setSearchParams({}); }} className="mt-6 text-amber-600 font-bold hover:underline">
                Clear all filters
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

// --- PLACEHOLDER COMPONENTS (STUBS) ---
const Login = ({ lang, navigate }: any) => {
  return (
    <div className="pt-32 pb-20 max-w-xl mx-auto px-6 min-h-screen text-center">
      <h1 className="text-4xl font-bold dark:text-white mb-4">Sign In / Join Panora</h1>
      <p className="text-slate-500 mb-8">This is the placeholder for the authentication page.</p>
      <div className="space-y-4">
        <button className="w-full py-3 rounded-xl font-bold bg-amber-500 text-white hover:bg-amber-600 transition-colors">Continue with Email</button>
        <button className="w-full py-3 rounded-xl font-bold bg-slate-100 dark:bg-slate-800 text-slate-900 dark:text-white border border-slate-200 dark:border-slate-700 flex items-center justify-center space-x-2 hover:bg-slate-200 dark:hover:bg-slate-700 transition-colors">
          <LucideApple size={20} /><span>Continue with Apple</span>
        </button>
        <button onClick={() => navigate('home')} className="mt-6 text-amber-600 font-bold hover:underline">Go back home</button>
      </div>
    </div>
  );
};

const Reviews = ({ lang }: any) => {
  return (
    <div className="pt-32 pb-20 max-w-4xl mx-auto px-6 min-h-screen text-center">
      <h1 className="text-4xl font-bold dark:text-white mb-4">Guest Reviews & Ratings</h1>
      <p className="text-slate-500 mb-8">This is the placeholder for all community reviews.</p>
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ReviewCard rating={5} comment="Simply the best way to book in Zimbabwe. Everything was seamless, and the host was fantastic." author="Nomusa M." />
        <ReviewCard rating={4.5} comment="The Explore page filters made finding our perfect lodge in Hwange so easy. Highly recommend Panora." author="David C." />
      </div>
    </div>
  );
};

const ReviewCard = ({ rating, comment, author }: any) => (
  <div className="bg-white dark:bg-slate-800 p-6 rounded-xl shadow-md text-left">
    <div className="flex items-center mb-3">
      {[...Array(5)].map((_, i) => (
        <Star key={i} size={16} className={`mr-0.5 ${i < Math.floor(rating) ? 'fill-amber-400 text-amber-400' : 'text-slate-300 dark:text-slate-600'}`} />
      ))}
      <span className="ml-2 text-sm font-bold dark:text-white">{rating}</span>
    </div>
    <p className="text-slate-700 dark:text-slate-300 italic mb-4">"{comment}"</p>
    <p className="font-semibold text-sm dark:text-white">- {author}</p>
  </div>
);


const AITripPlanner = React.forwardRef<HTMLElement, {}>((props, ref) => {
  // Placeholder logic for AI planner
  const [query, setQuery] = useState('');
  const [tripIdea, setTripIdea] = useState<any | null>(null);
  const [loading, setLoading] = useState(false);

  // Mock API call to generate structured JSON response
  const generateTripIdea = async (prompt: string) => {
    // In a real application, you would make the API call here.
    await new Promise(resolve => setTimeout(resolve, 1500)); 

    return {
      title: "The Ultimate Nyanga Romantic Getaway",
      theme: "A 3-day luxurious trip focused on relaxation and mountain views.",
      days: [
        { dayNumber: 1, activity: "Arrival and Vumba Luxury Check-in", description: "Check into your private villa at Leopard Rock, followed by a sunset cocktail overlooking the mountains." },
        { dayNumber: 2, activity: "Hike and High Tea", description: "Morning hike up Nyamhuka Mountain, followed by a traditional high tea experience at the resort." },
        { dayNumber: 3, activity: "Scenic Drive and Departure", description: "Enjoy a final scenic breakfast, drive the Eastern Highlands route, and depart." },
      ]
    };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;
    setLoading(true); setTripIdea(null);
    const result = await generateTripIdea(query);
    setTripIdea(result); setLoading(false);
  };

  return (
    <section ref={ref} className="max-w-7xl mx-auto px-6 py-20">
      <div className="bg-slate-900 dark:bg-slate-800 text-white p-8 md:p-12 rounded-3xl grid grid-cols-1 lg:grid-cols-3 gap-10 shadow-2xl">
        <div className="lg:col-span-1">
          <Lightbulb size={32} className="text-amber-400 mb-4" />
          <h2 className="text-3xl font-bold mb-3">AI Adventure Planner</h2>
          <p className="text-slate-300 mb-6">Tell us your dream trip, and we'll craft the perfect Zimbabwean itinerary.</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input type="text" value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. A romantic weekend in Nyanga" className="w-full px-4 py-3 rounded-xl text-slate-900 bg-white focus:ring-2 focus:ring-amber-500 outline-none" disabled={loading} />
            <button type="submit" disabled={loading || !query.trim()} className="w-full bg-amber-500 hover:bg-amber-600 text-slate-900 font-bold py-3 rounded-xl flex items-center justify-center space-x-2 transition-colors disabled:opacity-50">
              {loading ? <Loader2 size={20} className="animate-spin" /> : <Send size={20} />}<span>Generate</span>
            </button>
          </form>
        </div>
        <div className="lg:col-span-2 min-h-[300px] relative">
          <AnimatePresence mode="wait">
            {tripIdea ? (
              <motion.div 
                key="itinerary"
                initial={{ opacity: 0, y: 10 }} 
                animate={{ opacity: 1, y: 0 }} 
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.5 }}
                className="bg-white/10 p-6 rounded-xl backdrop-blur-sm border border-white/10 h-full"
              >
                <h3 className="text-2xl font-bold text-amber-400 mb-2">{tripIdea.title}</h3>
                <p className="text-slate-300 mb-6 italic">{tripIdea.theme}</p>
                <div className="space-y-4">
                  {tripIdea.days.map((day: any, i: number) => (
                    <div key={i} className="pl-4 border-l-2 border-amber-500/50"><div className="font-bold text-amber-400">Day {day.dayNumber}: {day.activity}</div><p className="text-sm text-slate-300">{day.description}</p></div>
                  ))}
                </div>
              </motion.div>
            ) : (
              <motion.div 
                key="placeholder"
                initial={{ opacity: 0 }} 
                animate={{ opacity: 1 }}
                exit={{ opacity: 0 }}
                className="absolute inset-0 flex items-center justify-center text-slate-500"
              >
                <p>Your itinerary will appear here.</p>
              </motion.div>
            )}
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
});

const Footer = ({ lang, navigate }: any) => {
  const t = TRANSLATIONS[lang];
  return (
    <footer className="bg-slate-900 dark:bg-black text-white pt-20 pb-10 border-t border-slate-800">
      <div className="max-w-7xl mx-auto px-6 grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
        <div>
          <div className="font-bold text-2xl tracking-tighter mb-6">PANORA<span className="text-amber-500">.</span></div>
          <p className="text-slate-400 text-sm">Discover, Connect, Belong.</p>
        </div>
        <div>
          <h4 className="font-bold mb-6">Support</h4>
          <ul className="space-y-3 text-slate-400 text-sm">
            <li><a href={`mailto:${ADMIN_EMAIL}`} className="hover:text-white transition-colors">Help Center</a></li>
            <li><a href={`mailto:${ADMIN_EMAIL}`} className="hover:text-white transition-colors">Safety</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-6">Community</h4>
          <ul className="space-y-3 text-slate-400 text-sm">
            <li><button onClick={() => navigate('hosting')} className="hover:text-white transition-colors">List your place</button></li>
            <li><a href="/blog" className="hover:text-white transition-colors">Travel Blog</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-6">Newsletter</h4>
          <form action={`mailto:${ADMIN_EMAIL}`} method="post" encType="text/plain" className="flex">
            <input type="email" name="email" placeholder="Email" className="bg-slate-800 text-white px-4 py-2 rounded-l-lg outline-none w-full text-sm focus:ring-1 focus:ring-amber-500" />
            <button type="submit" className="bg-amber-500 px-4 rounded-r-lg font-bold hover:bg-amber-600 transition-colors">Go</button>
          </form>
        </div>
      </div>
      <div className="max-w-7xl mx-auto px-6 pt-8 border-t border-slate-800 flex justify-between text-slate-500 text-sm">
        <p>&copy; 2025 Panora Travels.</p>
      </div>
    </footer>
  );
};